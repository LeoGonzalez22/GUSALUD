from builtins import ImportError, ValueError
import csv
import hashlib
import json
import os
import re
import subprocess
import sys
import time
from datetime import date, datetime
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from openai import OpenAI
from pydantic import BaseModel, Field

BASE = os.path.dirname(os.path.abspath(__file__))
VENV = os.path.join(BASE, ".venv")
PYV = os.path.join(VENV, "Scripts", "python.exe") if os.name == "nt" else os.path.join(VENV, "bin", "python")

try:
    from openpyxl import Workbook, load_workbook # type: ignore
except ImportError:
    try:
        if sys.executable != PYV:
            if not os.path.exists(PYV):
                subprocess.check_call([sys.executable, "-m", "venv", VENV])
            subprocess.check_call([PYV, "-m", "pip", "install", "openpyxl"])
            if __name__ == "__main__":
                raise SystemExit(subprocess.call([PYV] + sys.argv))
            if os.name == "nt":
                sitio = os.path.join(VENV, "Lib", "site-packages")
            else:
                version = str(sys.version_info.major) + "." + str(sys.version_info.minor)
                sitio = os.path.join(VENV, "lib", "python" + version, "site-packages")
            sys.path.insert(0, sitio)
            from openpyxl import Workbook, load_workbook 
        else:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "openpyxl"])
            from openpyxl import Workbook, load_workbook 
    except (OSError, subprocess.CalledProcessError, ImportError):
        raise SystemExit("No se pudo instalar openpyxl.")

BITACORA = "bitacora_cambios.csv"
RECHAZADOS = "registros_rechazados.csv"
LISTADOS = "listados_pendientes.xlsx"
ARCHIVO_CONFIG = os.path.join(BASE, ".vacunacion_config.json")
CORTE = date(2026, 9, 30)
COLUMNAS = ["id", "documento", "nombres", "apellidos", "sexo", "fecha_nacimiento",
            "municipio", "comunidad", "semanas", "ths", "comorbilidad",
            "faltan", "vencidas", "nunca"]
MUNICIPIOS = {
    "44001": ("Riohacha", 7), "44035": ("Albania", 7),
    "44078": ("Barrancas", 5), "44090": ("Dibulla", 2),
    "44098": ("Distraccion", 2), "44110": ("El Molino", 5),
    "44279": ("Fonseca", 2), "44378": ("Hatonuevo", 2),
    "44420": ("La Jagua del Pilar", 2), "44430": ("Maicao", 2),
    "44560": ("Manaure", 3), "44650": ("San Juan del Cesar", 4),
    "44847": ("Uribia", 4), "44855": ("Urumita", 2),
    "44874": ("Villanueva", 4),
}
PESOS = {"SRP": 5, "POLIO": 5, "DPT": 5, "FA": 4, "NEUMO": 4,
         "TD": 4, "HEPB": 4, "BCG": 4, "ROTA": 3, "INFLUENZA": 3,
         "VPH": 3, "VARICELA": 2, "HEPA": 2, "COVID19": 1}
SERIE = {
    "BCG": ((0,), 71), "HEPB": ((0,), 1),
    "DPT": ((2, 4, 6, 18, 60), 71), "POLIO": ((2, 4, 6, 18, 60), 71),
    "ROTA": ((2, 4), 8), "NEUMO": ((2, 4, 12), 71),
    "SRP": ((12, 18), 71), "VARICELA": ((12, 60), 71), "HEPA": ((12,), 71),
}
NOMBRES = {
    "SRP": "triple viral", "POLIO": "polio", "DPT": "difteria, tosferina y tetanos",
    "FA": "fiebre amarilla", "NEUMO": "neumococo", "TD": "tetanos y difteria",
    "HEPB": "hepatitis B", "BCG": "BCG", "ROTA": "rotavirus",
    "INFLUENZA": "influenza", "VPH": "virus del papiloma humano",
    "VARICELA": "varicela", "HEPA": "hepatitis A", "COVID19": "COVID-19",
}

def ruta(nombre):
    return nombre if os.path.isabs(nombre) else os.path.join(BASE, nombre)

def registrar_archivo_datos(nombre):
    """Recuerda el archivo elegido en el menú para que la API lo reutilice."""
    origen = os.path.abspath(ruta(nombre))
    temporal = ARCHIVO_CONFIG + ".tmp"
    with open(temporal, "w", encoding="utf-8") as arch:
        json.dump({"archivo": origen}, arch, ensure_ascii=False)
    os.replace(temporal, ARCHIVO_CONFIG)

def archivo_datos_registrado():
    """Devuelve el archivo actual; VACUNACION_ARCHIVO permite configurarlo explícitamente."""
    configurado = os.getenv("VACUNACION_ARCHIVO")
    if configurado:
        return os.path.abspath(configurado)
    try:
        with open(ARCHIVO_CONFIG, encoding="utf-8") as arch:
            configurado = json.load(arch).get("archivo")
    except (OSError, ValueError, AttributeError):
        return None
    return os.path.abspath(configurado) if configurado else None

def edad_meses(nac, corte):
    n = (corte.year - nac.year) * 12 + corte.month - nac.month
    if corte.day < nac.day:
        n -= 1
    return max(n, 0)

def fecha(valor):
    if isinstance(valor, datetime):
        return valor.date()
    if isinstance(valor, date):
        return valor
    texto = str(valor or "").strip()
    for formato in ("%Y-%m-%d", "%d/%m/%Y", "%Y-%m-%d %H:%M:%S"):
        try:
            return datetime.strptime(texto, formato).date()
        except ValueError:
            pass
    raise ValueError("fecha invalida")

def booleano(valor):
    if isinstance(valor, (int, float)):
        if valor in (0, 1):
            return bool(valor)
    texto = str(valor or "").strip().lower()
    if texto in ("1", "1.0", "s", "si", "true", "x"):
        return True
    if texto in ("", "0", "0.0", "n", "no", "false"):
        return False
    raise ValueError("use 1 o 0")

def vacunas(valor):
    texto = str(valor or "").strip()
    if texto in ("", "-", "ninguna"):
        return set()
    salida = set()
    for parte in re.split(r"[|,;]", texto):
        cod = parte.strip().upper()
        if cod:
            if cod not in PESOS:
                raise ValueError("vacuna desconocida: " + cod)
            salida.add(cod)
    return salida

def estado(p, vac, corte):
    meses = edad_meses(p["nacimiento"], corte)
    anios = meses // 12
    sexo = p["sexo"]
    if vac in SERIE:
        if meses >= 72:
            return "NO_APLICA"
        edades, maximo = SERIE[vac]
        if not any(meses >= x for x in edades):
            return "NO_APLICA"
        if vac in p["faltan"]:
            return "NO_APLICA" if meses > maximo else "PENDIENTE"
        return "AL_DIA"
    if vac == "VPH":
        aplica = sexo == "F" and 9 <= anios <= 17 or sexo == "M" and anios == 9
    elif vac == "FA":
        aplica = meses >= 18 and p["municipio"] in MUNICIPIOS
    elif vac == "INFLUENZA":
        aplica = (sexo == "F" and p["semanas"] >= 14) or 7 <= meses <= 23 or anios > 60 or p["ths"] or p["comorbilidad"]
    elif vac == "COVID19":
        aplica = anios > 60 or p["ths"] or p["comorbilidad"]
    elif vac == "TD":
        aplica = sexo == "F" and 9 <= anios <= 49
    else:
        aplica = False
    if not aplica:
        return "NO_APLICA"
    if vac in p["faltan"] or vac in p["nunca"]:
        return "PENDIENTE"
    if vac in p["vencidas"]:
        return "VENCIDO"
    return "AL_DIA"

def evaluar(p, corte):
    pendientes = []
    carga = 0
    for vac in PESOS:
        if estado(p, vac, corte) in ("PENDIENTE", "VENCIDO"):
            pendientes.append(vac)
            carga += PESOS[vac]
    zona = MUNICIPIOS[p["municipio"]][1] if pendientes else 0
    puntos = carga + zona
    nivel = "URGENTE" if puntos > 10 else "IMPORTANTE" if puntos >= 6 else "CORTO PLAZO"
    return {"pendientes": pendientes, "carga": carga, "puntos": puntos,
            "nivel": nivel if pendientes else ""}

def validar(fila, corte):
    p = {}
    for campo in ("id", "documento", "nombres", "apellidos", "comunidad"):
        p[campo] = " ".join(str(fila.get(campo) or "").split())
        if not p[campo]:
            raise ValueError("falta " + campo)
    p["sexo"] = str(fila.get("sexo") or "").strip().upper()
    if p["sexo"] not in ("F", "M"):
        raise ValueError("sexo debe ser F o M")
    p["nacimiento"] = fecha(fila.get("fecha_nacimiento"))
    if p["nacimiento"] > corte or p["nacimiento"].year < 1900:
        raise ValueError("fecha de nacimiento fuera de rango")
    p["municipio"] = str(fila.get("municipio") or "").strip()
    if p["municipio"].endswith(".0"):
        p["municipio"] = p["municipio"][:-2]
    if p["municipio"] not in MUNICIPIOS:
        raise ValueError("municipio desconocido")
    try:
        p["semanas"] = int(float(str(fila.get("semanas") or 0).replace(",", ".")))
    except ValueError:
        raise ValueError("semanas invalidas")
    if not 0 <= p["semanas"] <= 45 or p["sexo"] == "M" and p["semanas"]:
        raise ValueError("semanas invalidas")
    p["ths"] = booleano(fila.get("ths"))
    p["comorbilidad"] = booleano(fila.get("comorbilidad"))
    p["faltan"] = vacunas(fila.get("faltan"))
    p["vencidas"] = vacunas(fila.get("vencidas"))
    p["nunca"] = vacunas(fila.get("nunca"))
    if p["faltan"] & p["vencidas"] or p["faltan"] & p["nunca"] or p["vencidas"] & p["nunca"]:
        raise ValueError("una vacuna aparece en mas de un estado")
    for vac in p["faltan"] | p["vencidas"] | p["nunca"]:
        if estado(p, vac, corte) == "NO_APLICA":
            raise ValueError(vac + " no aplica a esta persona")
    p["nombre"] = p["nombres"] + " " + p["apellidos"]
    p["resultado"] = evaluar(p, corte)
    return p

def leer(ruta_archivo):
    ext = os.path.splitext(ruta_archivo)[1].lower()
    filas = []
    if ext in (".xlsx", ".xlsm"):
        libro = load_workbook(ruta_archivo, read_only=True, data_only=True)
        hoja = libro["Personas"] if "Personas" in libro.sheetnames else libro.worksheets[0]
        it = hoja.iter_rows(values_only=True)
        encabezado = [str(x or "").strip().lower() for x in next(it, [])]
        if set(COLUMNAS) - set(encabezado):
            libro.close()
            raise ValueError("faltan columnas obligatorias: " + ", ".join(c for c in COLUMNAS if c not in encabezado))
        for num, vals in enumerate(it, 2):
            if any(x is not None and str(x).strip() for x in vals):
                filas.append((num, dict(zip(encabezado, vals))))
        libro.close()
    else:
        with open(ruta_archivo, encoding="utf-8-sig", newline="") as arch:
            muestra = arch.read(2048)
            arch.seek(0)
            sep = ";" if muestra.count(";") > muestra.count(",") else ","
            lector = csv.DictReader(arch, delimiter=sep)
            encabezado = [str(x or "").strip().lower() for x in (lector.fieldnames or [])]
            if set(COLUMNAS) - set(encabezado):
                raise ValueError("faltan columnas obligatorias: " + ", ".join(c for c in COLUMNAS if c not in encabezado))
            for num, fila in enumerate(lector, 2):
                filas.append((num, {str(k or "").strip().lower(): v for k, v in fila.items()}))
    return filas

def carga(nombre, corte, base=None):
    inicio = time.perf_counter()
    filas = leer(ruta(nombre))
    usados = set()
    docs = set()
    personas = []
    rechazados = []
    for num, fila in filas:
        try:
            p = validar(fila, corte)
            if p["id"] in usados:
                raise ValueError("id repetido")
            if p["documento"] in docs:
                raise ValueError("documento repetido")
            usados.add(p["id"])
            docs.add(p["documento"])
            personas.append(p)
        except (ValueError, TypeError) as e:
            rechazados.append((num, str(e)))
    lectura_ms = (time.perf_counter() - inicio) * 1000
    if base:
        with open(ruta(RECHAZADOS), "w", encoding="utf-8-sig", newline="") as arch:
            w = csv.writer(arch)
            w.writerow(["fila", "motivo"])
            w.writerows(rechazados)
    return personas, rechazados, len(filas), lectura_ms

def agrupar(personas):
    grupos = {}
    for p in personas:
        p["resultado"] = evaluar(p, CORTE)
        grupos.setdefault((p["municipio"], p["comunidad"]), []).append(p)
    return grupos

def indice(grupo, cod):
    if not grupo:
        return 0
    con = 0
    carga = 0
    for p in grupo:
        if p["resultado"]["pendientes"]:
            con += 1
        carga += p["resultado"]["carga"]
    prop = 100 * con / len(grupo)
    normal = 100 * (carga / len(grupo)) / sum(PESOS.values())
    zona = 100 * MUNICIPIOS[cod][1] / 7
    return round(prop * .6 + normal * .3 + zona * .1, 1)

def por_municipio(personas):
    grupos = agrupar(personas)
    ciudades = {}
    for (cod, comunidad), grupo in grupos.items():
        ciudades.setdefault(cod, []).extend(grupo)
    pares = []
    for cod, lista in ciudades.items():
        datos = (indice(lista, cod), len(lista),
                 sum(bool(p["resultado"]["pendientes"]) for p in lista))
        pares.append((-datos[0], MUNICIPIOS[cod][0], cod, datos))
    pares.sort()
    return [(cod, datos) for puntos, nombre, cod, datos in pares]

def log(accion, pid, detalle):
    nuevo = not os.path.exists(ruta(BITACORA))
    with open(ruta(BITACORA), "a", encoding="utf-8-sig", newline="") as arch:
        w = csv.writer(arch)
        if nuevo:
            w.writerow(["fecha", "accion", "id", "detalle"])
        w.writerow([datetime.now().isoformat(timespec="seconds"), accion, pid, detalle])

def filas_excel(personas):
    filas = []
    for p in personas:
        filas.append([p["id"], p["documento"], p["nombres"], p["apellidos"], p["sexo"],
                      p["nacimiento"], p["municipio"], p["comunidad"], p["semanas"],
                      int(p["ths"]), int(p["comorbilidad"]), "|".join(sorted(p["faltan"])),
                      "|".join(sorted(p["vencidas"])), "|".join(sorted(p["nunca"]))])
    return filas

def escribir(ruta_salida, hojas):
    libro = Workbook()
    libro.remove(libro.active)
    for nombre, cab, filas in hojas:
        hoja = libro.create_sheet(nombre)
        hoja.append(cab)
        for fila in filas:
            hoja.append(fila)
        hoja.freeze_panes = "A2"
        hoja.auto_filter.ref = hoja.dimensions
    temp = ruta_salida + ".tmp.xlsx"
    libro.save(temp)
    os.replace(temp, ruta_salida)

def guardar(personas, archivo):
    destino = ruta(archivo)
    extension = os.path.splitext(destino)[1].lower()
    if extension == ".xlsm":
        raise ValueError("guarda primero el archivo como .xlsx para editarlo")
    if extension == ".xlsx":
        escribir(destino, [("Personas", COLUMNAS, filas_excel(personas))])
        return
    temp = destino + ".tmp"
    with open(temp, "w", encoding="utf-8-sig", newline="") as arch:
        w = csv.writer(arch)
        w.writerow(COLUMNAS)
        w.writerows(filas_excel(personas))
    os.replace(temp, destino)

def resumen(grupos, municipio=None):
    total = 0
    filas = []
    for (cod, comunidad), grupo in sorted(grupos.items()):
        if municipio and cod != municipio:
            continue
        con = [p for p in grupo if p["resultado"]["pendientes"]]
        total += len(con)
        indice_grupo = indice(grupo, cod)
        vac = {}
        for p in con:
            for v in p["resultado"]["pendientes"]:
                vac[v] = vac.get(v, 0) + 1
        top = sorted(vac, key=vac.get, reverse=True)[:3]
        if con:
            filas.append((cod, comunidad, len(grupo), len(con), indice_grupo, top))
    return filas, total

def mensaje(fila):
    cod, comunidad, total, con, valor, top = fila
    vacunas_txt = ", ".join(NOMBRES[v] for v in top) if top else "las vacunas pendientes"
    return (f"En {comunidad}, municipio de {MUNICIPIOS[cod][0]}, hay {con} personas "
            f"con vacunas pendientes. Las mas frecuentes son {vacunas_txt}. "
            "El personal de salud coordinara la jornada.")

def ordenar(personas):
    grupos = agrupar(personas)
    salida = []
    for (cod, comunidad), grupo in sorted(grupos.items()):
        for p in grupo:
            if p["resultado"]["pendientes"]:
                puntos = p["resultado"]["puntos"]
                salida.append((-puntos, cod, comunidad, p["id"], puntos, p))
    salida.sort()
    return salida, grupos

def exportar(personas, nombre=LISTADOS):
    lista, grupos = ordenar(personas)
    filas = []
    for negativo, cod, comunidad, pid, puntos, p in lista:
        filas.append([MUNICIPIOS[cod][0], comunidad, p["resultado"]["nivel"], puntos,
                      p["id"], p["documento"], p["nombre"],
                      ", ".join(p["resultado"]["pendientes"])])
    res, total = resumen(grupos)
    comun = []
    for cod, comunidad, pers, con, val, top in res:
        comun.append([MUNICIPIOS[cod][0], comunidad, pers, con, val,
                      "ALTO" if val >= 30 else "MEDIO" if val >= 18 else "BAJO",
                      mensaje((cod, comunidad, pers, con, val, top))])
    escribir(ruta(nombre), [
        ("Pendientes", ["municipio", "comunidad", "prioridad", "puntaje", "id",
                        "documento", "nombre", "vacunas"], filas),
        ("Comunidades", ["municipio", "comunidad", "personas", "pendientes",
                         "indice", "nivel", "mensaje"], comun)])
    return len(filas)

def hash_archivo(nombre):
    h = hashlib.sha256()
    try:
        with open(ruta(nombre), "rb") as arch:
            bloque = arch.read(1024 * 1024)
            while bloque:
                h.update(bloque)
                bloque = arch.read(1024 * 1024)
        return h.hexdigest()
    except OSError:
        return ""

def cargar_inicio(nombre):
    origen_hash = hash_archivo(nombre)
    try:
        personas, rechazados, leidas, ms = carga(nombre, CORTE, True)
    except (OSError, ValueError, RuntimeError) as e:
        print("No se pudo cargar", nombre, ":", e)
        return {"archivo": nombre, "personas": [], "rechazados": [], "leidas": 0,
                "carga_ms": 0, "grupo_ms": 0, "hash": origen_hash, "ok": 0, "error": 0}
    registrar_archivo_datos(nombre)
    t = time.perf_counter()
    grupos = agrupar(personas)
    grupo_ms = (time.perf_counter() - t) * 1000
    print("Archivo:", nombre, "| leidos:", leidas, "| cargados:", len(personas),
          "| rechazados:", len(rechazados))
    if rechazados:
        print("Detalle guardado en", RECHAZADOS)
    return {"archivo": nombre, "personas": personas, "rechazados": rechazados, "leidas": leidas,
            "carga_ms": ms, "grupo_ms": grupo_ms, "hash": origen_hash, "ok": 0, "error": 0}

def listar(personas, orden="prioridad", municipio=None):
    lista, grupos = ordenar(personas)
    if orden == "municipio":
        lista.sort(key=lambda x: (MUNICIPIOS[x[1]][0], x[2], x[0], x[3]))
    elif orden == "sector":
        lista.sort(key=lambda x: (MUNICIPIOS[x[1]][1], MUNICIPIOS[x[1]][0], x[2], x[0], x[3]))
    elif orden == "comunidad":
        lista.sort(key=lambda x: (x[2], MUNICIPIOS[x[1]][0], x[0], x[3]))
    vistos = set()
    for negativo, cod, comunidad, pid, puntos, p in lista:
        if municipio and cod != municipio:
            continue
        clave = (cod, comunidad)
        if clave != vistos:
            sector = MUNICIPIOS[cod][1]
            print("\nSector", sector, "|", MUNICIPIOS[cod][0], "/", comunidad)
            vistos = clave
        print(p["id"], p["nombre"], "|", p["resultado"]["nivel"], "|",
              ", ".join(p["resultado"]["pendientes"]))
    if not lista:
        print("No hay personas con vacunas pendientes.")

def consulta(personas, municipio):
    t = time.perf_counter()
    grupos = agrupar(personas)
    filas, total = resumen(grupos, municipio)
    for cod, comunidad, pers, con, val, top in filas:
        print(MUNICIPIOS[cod][0], "/", comunidad, "|", pers, "personas |",
              con, "pendientes | indice", val)
    print("Total de personas pendientes:", total)
    return (time.perf_counter() - t) * 1000

def mensajes(personas):
    grupos = agrupar(personas)
    filas, total = resumen(grupos)
    for fila in filas:
        print(mensaje(fila))
    if not filas:
        print("No hay comunidades con pendientes.")

def kpis(app, consulta_ms=0):
    personas = app["personas"]
    print("Carga:", round(app["carga_ms"], 2), "ms | agrupacion:", round(app["grupo_ms"], 2), "ms")
    
    print("Consulta:", round(consulta_ms, 2), "ms")


    total = app["ok"] + app["error"]
    tasa = 100 * app["ok"] / total if total else 0
    print("Reportes correctos:", app["ok"], "| errores:", app["error"],
          "| exito:", round(tasa, 1), "%")

    
    print("Integridad: leidos =", app["leidas"], "| cargados + rechazados =",
          len(personas) + len(app["rechazados"]))
    ids = [p["id"] for p in personas]
    grupos = agrupar(personas)
    cuenta = sum(len(g) for g in grupos.values())


    print("Ids unicos:", len(ids) == len(set(ids)), "| una comunidad por persona:",
          cuenta == len(personas))
    print("Archivo sin cambios:", bool(app["hash"]) and app["hash"] == hash_archivo(app["archivo"]))
    print("Escalabilidad:")
    for n in (1000, 2500, 5000, 10000):
        muestra = personas[:n]
        t = time.perf_counter()
        agrupar(muestra)
        ms = (time.perf_counter() - t) * 1000
        print(n, "registros:", round(ms, 2), "ms")

def fila_actual(p):
    return {"id": p["id"], "documento": p["documento"], "nombres": p["nombres"],
            "apellidos": p["apellidos"], "sexo": p["sexo"],
            "fecha_nacimiento": p["nacimiento"].isoformat(), "municipio": p["municipio"],
            "comunidad": p["comunidad"], "semanas": p["semanas"], "ths": int(p["ths"]),
            "comorbilidad": int(p["comorbilidad"]), "faltan": "|".join(p["faltan"]),
            "vencidas": "|".join(p["vencidas"]), "nunca": "|".join(p["nunca"])}

def pedir_persona():
    fila = {}
    for campo, defecto in (("id", ""), ("documento", ""), ("nombres", ""),
                           ("apellidos", ""), ("sexo", "F"),
                           ("fecha_nacimiento", ""), ("municipio", ""),
                           ("comunidad", ""), ("semanas", "0"), ("ths", "0"),
                           ("comorbilidad", "0"), ("faltan", ""), ("vencidas", ""),
                           ("nunca", "")):
        valor = input(campo + (f" [{defecto}]" if defecto else "") + ": ").strip()
        fila[campo] = valor or defecto
    return fila

def buscar(personas):
    dato = input("Id, documento o nombre: ").strip().lower()
    for p in personas:
        if dato in (p["id"].lower(), p["documento"].lower()) or dato in p["nombre"].lower():
            print(p["id"], p["nombre"], "|", MUNICIPIOS[p["municipio"]][0],
                  "/", p["comunidad"], "|", ", ".join(p["resultado"]["pendientes"]))
            return p
    print("No se encontro.")
    return None

def actualizar(personas, archivo, accion):
    p = buscar(personas)
    if not p:
        return
    cambios = {}
    for campo in ("documento", "nombres", "apellidos", "sexo", "fecha_nacimiento",
                  "municipio", "comunidad", "semanas", "ths", "comorbilidad",
                  "faltan", "vencidas", "nunca"):
        actual = fila_actual(p)[campo]
        nuevo = input(campo + f" [{actual}]: ").strip()
        cambios[campo] = nuevo or actual
    cambios["id"] = p["id"]
    otros = [x for x in personas if x is not p]
    nuevo = validar(cambios, CORTE)
    if any(x["documento"] == nuevo["documento"] for x in otros):
        print("Documento repetido.")
        return
    p.clear()
    p.update(nuevo)
    log(accion, p["id"], "datos actualizados")
    guardar(personas, archivo)
    print("Cambios guardados en", archivo)

def agregar(personas, archivo):
    try:
        nuevo = validar(pedir_persona(), CORTE)
        if any(x["id"] == nuevo["id"] for x in personas):
            raise ValueError("id repetido")
        if any(x["documento"] == nuevo["documento"] for x in personas):
            raise ValueError("documento repetido")
    except ValueError as e:
        print("Dato invalido:", e)
        return
    personas.append(nuevo)
    log("AGREGAR", nuevo["id"], nuevo["nombre"])
    guardar(personas, archivo)
    print("Persona agregada.")

def quitar(personas, archivo):
    p = buscar(personas)
    if not p:
        return
    if input("Eliminar? (s/n): ").strip().lower() == "s":
        personas.remove(p)
        log("ELIMINAR", p["id"], p["nombre"])
        guardar(personas, archivo)
        print("Persona eliminada.")

def aplicada(personas, archivo):
    p = buscar(personas)
    if not p:
        return
    pendientes = p["resultado"]["pendientes"]
    print("Pendientes:", ", ".join(pendientes))
    vac = input("Codigo de vacuna aplicada: ").strip().upper()
    if vac not in pendientes:
        print("La vacuna no esta pendiente.")
        return
    for campo in ("faltan", "vencidas", "nunca"):
        p[campo].discard(vac)
    p["resultado"] = evaluar(p, CORTE)
    log("VACUNA", p["id"], vac)
    guardar(personas, archivo)
    print("Vacuna registrada.")

def importar(app):
    nombre = input("Archivo Excel o CSV: ").strip()
    if not nombre:
        return
    try:
        personas, rechazados, leidas, ms = carga(nombre, CORTE, True)
        app["personas"] = personas
        app["archivo"] = nombre
        app["rechazados"] = rechazados
        app["leidas"] = leidas
        app["carga_ms"] = ms
        app["hash"] = hash_archivo(nombre)
        registrar_archivo_datos(nombre)
        t = time.perf_counter()
        agrupar(personas)
        app["grupo_ms"] = (time.perf_counter() - t) * 1000
        log("CARGA", "-", nombre)
        print("Leidos:", leidas, "| cargados:", len(personas), "| rechazados:", len(rechazados))
    except (OSError, ValueError) as e:
        print("No se pudo cargar:", e)

def informe(app, funcion, *args):
    try:
        funcion(*args)
        app["ok"] += 1
    except Exception as e:
        app["error"] += 1
        print("No se pudo completar:", e)

def exportar_menu(personas):
    nombre = input("Archivo de salida [listados_pendientes.xlsx]: ").strip() or LISTADOS
    if not nombre.lower().endswith(".xlsx"):
        nombre += ".xlsx"
    print("Exportadas", exportar(personas, nombre), "personas a", nombre)

def main():
    nombre = input("Nombre o ruta del archivo Excel o CSV: ").strip()
    if not nombre:
        print("Debes indicar un archivo.")
        return
    app = cargar_inicio(nombre)
    consulta_ms = 0
    while True:
        print("\n1 Pendientes  2 Consultas  3 Reportes  4 Archivo  5 Personas  6 Indicadores  0 Salir")
        op = input("Opcion: ").strip()
        if op == "0":
            break
        if op == "1":
            while True:
                print("\nPendientes: 1 Prioridad  2 Sector  3 Municipio  4 Comunidad  0 Volver")
                sub = input("Opcion: ").strip()
                if sub == "0":
                    break
                orden = {"1": "prioridad", "2": "sector", "3": "municipio", "4": "comunidad"}.get(sub)
                if orden:
                    informe(app, listar, app["personas"], orden)
                else:
                    print("Opcion no valida.")
        elif op == "2":
            while True:
                print("\nConsultas: 1 Comunidades  2 Mensajes  0 Volver")
                sub = input("Opcion: ").strip()
                if sub == "0":
                    break
                if sub == "1":
                    cod = input("Codigo DANE del municipio (vacio=todos): ").strip()
                    if cod and cod not in MUNICIPIOS:
                        print("Municipio desconocido.")
                        continue
                    t = time.perf_counter()
                    informe(app, consulta, app["personas"], cod or None)
                    consulta_ms = (time.perf_counter() - t) * 1000
                elif sub == "2":
                    informe(app, mensajes, app["personas"])
                else:
                    print("Opcion no valida.")
        elif op == "3":
            while True:
                print("\nReportes: 1 Exportar listados  2 Indicadores  0 Volver")
                sub = input("Opcion: ").strip()
                if sub == "0":
                    break
                if sub == "1":
                    informe(app, exportar_menu, app["personas"])
                elif sub == "2":
                    kpis(app, consulta_ms)
                else:
                    print("Opcion no valida.")
        elif op == "4":
            while True:
                print("\nArchivo: 1 Cargar otro archivo  2 Ver archivo actual  0 Volver")
                sub = input("Opcion: ").strip()
                if sub == "0":
                    break
                if sub == "1":
                    importar(app)
                elif sub == "2":
                    print(app["archivo"])
                else:
                    print("Opcion no valida.")
        elif op == "5":
            while True:
                print("\nPersonas: 1 Agregar  2 Buscar  3 Actualizar  4 Registrar vacuna  5 Eliminar  0 Volver")
                sub = input("Opcion: ").strip().lower()
                archivo = app["archivo"]
                try:
                    if sub == "1":
                        agregar(app["personas"], archivo)
                    elif sub == "2":
                        buscar(app["personas"])
                    elif sub == "3":
                        actualizar(app["personas"], archivo, "ACTUALIZAR")
                    elif sub == "4":
                        aplicada(app["personas"], archivo)
                    elif sub == "5":
                        quitar(app["personas"], archivo)
                    elif sub == "0":
                        break
                except (OSError, ValueError) as e:
                    print("No se pudo guardar:", e)
        else:
            print("Opcion no valida.")
# API HTTP integrada: se inicia con `uvicorn vacunacion_guajira:app --reload`.
app = FastAPI(title="API de vacunación de La Guajira")
lm_studio = OpenAI(
    base_url=os.getenv("LM_STUDIO_BASE_URL", "http://localhost:1234/v1"),
    api_key=os.getenv("LM_API_TOKEN", "lm-studio"),
    timeout=60.0,
    max_retries=0,
)


@app.get("/", include_in_schema=False)
def pagina_inicio():
    return FileResponse(os.path.join(BASE, "index.html"), media_type="text/html")


@app.get("/styles.css", include_in_schema=False)
def pagina_estilos():
    return FileResponse(os.path.join(BASE, "styles.css"), media_type="text/css")


class PreguntaAPI(BaseModel):
    pregunta: str = Field(min_length=1, max_length=2000)


class ExplicarAPI(BaseModel):
    pregunta: str = Field(min_length=1, max_length=2000)
    persona: dict


class RezagoPruebaAPI(BaseModel):
    """Parámetros para calcular el índice con personas ficticias reproducibles."""
    cantidad: int = Field(default=1000, ge=1, le=10000)
    semilla: int = 2026
    municipio: str | None = Field(default=None, pattern=r"^\d{5}$")


@app.get("/salud")
def api_salud():
    return {"estado": "API activa"}


@app.post("/evaluar")
def api_evaluar(datos: dict):
    """Evalúa una persona aplicando las reglas deterministas existentes."""
    try:
        persona = validar(datos, CORTE)
    except (ValueError, TypeError) as error:
        raise HTTPException(status_code=400, detail=str(error))

    resultado = persona["resultado"]
    return {
        "id": persona["id"],
        "nombre": persona["nombre"],
        "pendientes": resultado["pendientes"],
        "carga": resultado["carga"],
        "puntos": resultado["puntos"],
        "nivel": resultado["nivel"],
    }


@app.get("/rezago")
def api_rezago(municipio: str | None = None):
    """Calcula el índice con los registros del archivo cargado previamente."""
    if municipio and municipio not in MUNICIPIOS:
        raise HTTPException(status_code=400, detail="Código de municipio desconocido.")

    archivo = archivo_datos_registrado()
    if not archivo:
        raise HTTPException(
            status_code=409,
            detail=(
                "Aún no hay un archivo de datos registrado. Ejecuta el programa de "
                "vacunación y carga tu archivo Excel o CSV una vez."
            ),
        )
    if not os.path.isfile(archivo):
        raise HTTPException(
            status_code=404,
            detail="El archivo registrado ya no existe. Cárgalo de nuevo desde el programa.",
        )

    try:
        personas, rechazados, leidas, _ = carga(archivo, CORTE)
    except (OSError, ValueError, RuntimeError) as error:
        raise HTTPException(status_code=400, detail="No se pudo leer el archivo: " + str(error))
    if not personas:
        raise HTTPException(status_code=422, detail="El archivo no contiene registros válidos.")

    grupos = agrupar(personas)
    codigos = [municipio] if municipio else sorted(
        {persona["municipio"] for persona in personas},
        key=lambda cod: MUNICIPIOS[cod][0],
    )
    resultados = []
    for cod in codigos:
        lista = [persona for persona in personas if persona["municipio"] == cod]
        comunidades = []
        for (cod_grupo, nombre_comunidad), grupo in grupos.items():
            if cod_grupo == cod:
                comunidades.append({
                    "comunidad": nombre_comunidad,
                    "personas": len(grupo),
                    "personas_con_pendientes": sum(
                        bool(persona["resultado"]["pendientes"]) for persona in grupo
                    ),
                    "indice": indice(grupo, cod),
                })
        comunidades.sort(key=lambda fila: -fila["indice"])
        resultados.append({
            "codigo_municipio": cod,
            "municipio": MUNICIPIOS[cod][0],
            "personas": len(lista),
            "personas_con_pendientes": sum(
                bool(persona["resultado"]["pendientes"]) for persona in lista
            ),
            "indice": indice(lista, cod),
            "comunidades": comunidades,
        })

    return {
        "archivo": os.path.basename(archivo),
        "registros_leidos": leidas,
        "registros_validos": len(personas),
        "registros_rechazados": len(rechazados),
        "formula": "60% personas con pendientes + 30% carga ponderada + 10% riesgo del municipio",
        "resultados": resultados,
    }


@app.get("/rezago/explicacion")

def api_explicacion_rezago(municipio: str | None = None):
    """Devuelve solo texto para la interfaz; no envía registros personales al modelo."""
    reporte = api_rezago(municipio)
    filas = reporte["resultados"]
    mayor = max(filas, key=lambda fila: fila["indice"], default=None)
    menor = min(filas, key=lambda fila: fila["indice"], default=None)
    pendientes_total = sum(fila["personas_con_pendientes"] for fila in filas)
    contexto = {
        "registros_validos": reporte["registros_validos"],
        "registros_rechazados": reporte["registros_rechazados"],
        "municipios_evaluados": len(filas),
        "personas_con_pendientes": pendientes_total,
        "municipio_con_indice_mayor": (
            {"municipio": mayor["municipio"], "indice": mayor["indice"]}
            if mayor else None
        ),
        "municipio_con_indice_menor": (
            {"municipio": menor["municipio"], "indice": menor["indice"]}
            if menor else None
        ),
        "formula": reporte["formula"],
    }
    if municipio:
        instruccion = (
            "Explica en una sola frase de máximo 20 palabras el índice del municipio "
            "evaluado y qué representa. Usa exclusivamente los valores actuales; "
            "no escribas listas, JSON ni razonamiento."
        )
    else:
        instruccion = (
            "Explica en una sola frase de máximo 20 palabras qué representa el índice "
            "y compara brevemente el municipio con índice más alto y el de índice más "
            "bajo. Usa exclusivamente los valores actuales recibidos; no escribas listas, "
            "JSON ni razonamiento."
        )
    explicacion = consultar_lm_studio(
        instruccion,
        contexto,
        max_tokens=1024,
    )
    if not explicacion.strip() or explicacion == "El modelo no generó texto.":
        explicacion = (
            "El índice combina la proporción de personas con pendientes, la carga "
            "ponderada de vacunas y el riesgo municipal."
        )

    if mayor:
        resumen_actual = (
            f"Datos actuales: {reporte['registros_validos']} registros válidos; "
            f"{pendientes_total} personas con pendientes. Mayor índice: "
            f"{mayor['municipio']} ({mayor['indice']}/100)."
        )
    else:
        resumen_actual = "No hay resultados para los datos seleccionados."
    return {"explicacion": resumen_actual + " " + explicacion}


def consultar_lm_studio(
    pregunta: str,
    contexto: dict | None = None,
    max_tokens: int = 512,
) -> str:
    """Envía texto y, opcionalmente, un resultado calculado al modelo local."""
    try:
        modelos = lm_studio.models.list().data
        if not modelos:
            raise HTTPException(
                status_code=503,
                detail="LM Studio está activo, pero no hay un modelo cargado.",
            )

        mensajes = [
            {
                "role": "system",
                "content": (
                    "Responde en español y de forma clara. Devuelve solo la respuesta "
                    "final; no incluyas razonamiento interno ni pasos de pensamiento. "
                    "No inventes datos ni des "
                    "diagnósticos médicos. Si recibes un resultado del sistema, "
                    "explícalo sin cambiar sus cálculos ni recomendar vacunas "
                    "distintas de las que aparecen allí."
                ),
            }
        ]
        texto_usuario = pregunta
        if contexto is not None:
            texto_usuario += (
                "\n\nResultado calculado por el backend (úsalo solo para explicar): "
                + str(contexto)
            )
        mensajes.append({"role": "user", "content": texto_usuario})

        respuesta = lm_studio.chat.completions.create(
            model=modelos[0].id,
            messages=mensajes,
            temperature=0.2,

            max_tokens=max_tokens,
        )
        return respuesta.choices[0].message.content or "El modelo no generó texto."
    except HTTPException:
        raise
    except Exception as error:
        raise HTTPException(
            status_code=503,
            detail=(
                "No se pudo conectar con LM Studio. Inicia su servidor, carga un "
                "modelo y verifica el puerto 1234. Detalle: " + str(error)
            ),
        )


@app.post("/preguntar")
def api_preguntar(datos: PreguntaAPI):
    """Envía una pregunta general al modelo de LM Studio."""
    return {"respuesta": consultar_lm_studio(datos.pregunta)}


@app.post("/explicar")
def api_explicar(datos: ExplicarAPI):
    """Calcula con las reglas del backend y pide al modelo una explicación."""
    try:
        persona = validar(datos.persona, CORTE)
    except (ValueError, TypeError) as error:
        raise HTTPException(status_code=400, detail=str(error))

    resultado = persona["resultado"]
    resumen = {
        "pendientes": resultado["pendientes"],
        "carga": resultado["carga"],
        "puntos": resultado["puntos"],
        "nivel": resultado["nivel"],
    }
    return {
        "evaluacion": resumen,
        "explicacion": consultar_lm_studio(datos.pregunta, resumen),
    }


@app.post("/rezago/prueba")
def api_rezago_prueba(datos: RezagoPruebaAPI):
    """Genera una muestra ficticia y calcula el índice con la función existente."""
    if datos.municipio and datos.municipio not in MUNICIPIOS:
        raise HTTPException(status_code=400, detail="Código de municipio desconocido.")

   
    from generador_datos import generar

    personas = generar(datos.cantidad, datos.semilla)
    grupos = agrupar(personas)
    codigos = [datos.municipio] if datos.municipio else sorted(
        {p["municipio"] for p in personas},
        key=lambda cod: MUNICIPIOS[cod][0],
    )

    resultados = []
    for cod in codigos:
        lista = [p for p in personas if p["municipio"] == cod]
        comunidades = []
        for (cod_grupo, comunidad), grupo in grupos.items():
            if cod_grupo == cod:
                comunidades.append({
                    "comunidad": comunidad,
                    "personas": len(grupo),
                    "personas_con_pendientes": sum(
                        bool(p["resultado"]["pendientes"]) for p in grupo
                    ),
                    "indice": indice(grupo, cod),
                })
        comunidades.sort(key=lambda fila: -fila["indice"])
        resultados.append({
            "codigo_municipio": cod,
            "municipio": MUNICIPIOS[cod][0],
            "personas": len(lista),
            "personas_con_pendientes": sum(
                bool(p["resultado"]["pendientes"]) for p in lista
            ),
            "indice": indice(lista, cod),
            "comunidades": comunidades,
        })

    return {
        "datos_ficticios": True,
        "cantidad_generada": len(personas),
        "semilla": datos.semilla,
        "formula": "60% personas con pendientes + 30% carga ponderada + 10% riesgo del municipio",
        "resultados": resultados,
    }

if __name__ == "__main__":
    main()
