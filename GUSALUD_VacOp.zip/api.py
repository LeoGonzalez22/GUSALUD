"""Punto de entrada compatible: la API vive en vacunacion_guajira.py."""
from vacunacion_guajira import app
