import os
import random
import sys
from collections import Counter
from datetime import timedelta

from vacunacion_guajira import CORTE, MUNICIPIOS, PESOS, SERIE, COLUMNAS
from vacunacion_guajira import edad_meses, estado, escribir, filas_excel

NOMBRES_F = ["Maria", "Luisa", "Ana", "Sofia", "Camila", "Valentina", "Daniela",
             "Yurley", "Karen", "Paola", "Leidys", "Mayerlin", "Yaneth", "Dayana",
             "Isabella", "Rosa", "Marleny", "Katherine", "Aleida", "Johana", "Laura"]
NOMBRES_M = ["Juan", "Carlos", "Luis", "Jose", "Andres", "Miguel", "Samuel", "Jhon",
             "Alexander", "Kevin", "Yeison", "Jorge", "Rafael", "Diego", "Santiago",
             "Pedro", "Wilmer", "Edwin", "Leonardo", "Sebastian", "Jairo"]
APELLIDOS = ["Gonzalez", "Rodriguez", "Gomez", "Martinez", "Perez", "Epieyu", "Pushaina",
             "Uriana", "Ipuana", "Jusayu", "Fernandez", "Lopez", "Ramirez", "Castro",
             "Mendoza", "Brito", "Iguaran", "Gouriyu", "Sijona", "Barros", "Redondo"]
COMUNIDADES = ["Las Flores", "El Cerrito", "La Esperanza", "Nuevo Amanecer", "Buenavista",
               "El Progreso", "San Isidro", "La Union", "Los Almendros", "Monte Verde",
               "Santa Rosa", "El Paraiso", "Villa Nueva", "La Gloria"]
PESOS_MUNICIPIO = {"44001": 10, "44035": 2, "44078": 3, "44090": 3, "44098": 1.5,
                   "44110": 1, "44279": 4, "44378": 2.5, "44420": 1, "44430": 12,
                   "44560": 6, "44650": 4, "44847": 10, "44855": 1.5, "44874": 3}

def nacimiento(azar):
    tramo = azar.choices((0, 1, 2, 3), (30, 15, 40, 15))[0]
    dias = ((0, 6 * 365 - 1), (6 * 365, 18 * 365 - 1),
            (18 * 365, 60 * 365 - 1), (60 * 365, 95 * 365))[tramo]
    return CORTE - timedelta(days=azar.randint(*dias))

def esquema(azar, p):
    riesgo = MUNICIPIOS[p["municipio"]][1]
    prob = 0.02 + 0.02 * riesgo
    for vac in PESOS:
        if estado(p, vac, CORTE) == "NO_APLICA" or azar.random() >= prob:
            continue
        if vac in SERIE and edad_meses(p["nacimiento"], CORTE) > SERIE[vac][1]:
            continue
        if vac in SERIE:
            p["faltan"].add(vac)
        else:
            campo = azar.choices(("faltan", "vencidas", "nunca"), (5, 3, 2))[0]
            p[campo].add(vac)

def generar(cantidad=10000, semilla=2026):
    azar = random.Random(semilla)
    codigos = list(MUNICIPIOS)
    comunidades = {}
    for cod in codigos:
        comunidades[cod] = azar.sample(COMUNIDADES, azar.randint(3, 6))
    personas = []
    for num in range(1, cantidad + 1):
        sexo = azar.choice(("F", "M"))
        nombres = NOMBRES_F if sexo == "F" else NOMBRES_M
        nombre = azar.choice(nombres)
        if azar.random() < 0.4:
            otro = azar.choice([x for x in nombres if x != nombre])
            nombre += " " + otro
        nac = nacimiento(azar)
        anios = edad_meses(nac, CORTE) // 12
        cod = azar.choices(codigos, [PESOS_MUNICIPIO[x] for x in codigos])[0]
        gestante = sexo == "F" and 15 <= anios <= 45 and azar.random() < 0.06
        comorb = 0.05 if anios < 40 else 0.15 if anios < 60 else 0.35
        p = {"id": f"P{num:05d}", "documento": f"TEST{num:05d}",
             "nombres": nombre, "apellidos": azar.choice(APELLIDOS) + " " + azar.choice(APELLIDOS),
             "sexo": sexo, "nacimiento": nac, "municipio": cod,
             "comunidad": azar.choice(comunidades[cod]),
             "semanas": azar.randint(4, 40) if gestante else 0,
             "ths": azar.random() < 0.03 if 18 <= anios <= 65 else False,
             "comorbilidad": azar.random() < comorb,
             "faltan": set(), "vencidas": set(), "nunca": set()}
        esquema(azar, p)
        personas.append(p)
    return personas

def main(cantidad=None, semilla=None, salida=None):
    consola = __name__ != "__main__"
    if cantidad is None:
        cantidad = int(sys.argv[1]) if not consola and len(sys.argv) > 1 else 10000
    if semilla is None:
        semilla = int(sys.argv[2]) if not consola and len(sys.argv) > 2 else 2026
    if salida is None:
        salida = sys.argv[3] if not consola and len(sys.argv) > 3 else "vacunacion_datos.xlsx"
    if not os.path.isabs(salida):
        salida = os.path.join(os.path.dirname(os.path.abspath(__file__)), salida)
    personas = generar(cantidad, semilla)
    escribir(salida, [("Personas", COLUMNAS, filas_excel(personas))])
    total = sum(bool(p["faltan"] or p["vencidas"] or p["nunca"]) for p in personas)
    cuenta = Counter(MUNICIPIOS[p["municipio"]][0] for p in personas)
    print("Generados:", len(personas), "| con pendientes:", total, "| archivo:", salida)
    print("Por municipio:", dict(cuenta.most_common()))

if __name__ == "__main__":
    main()
